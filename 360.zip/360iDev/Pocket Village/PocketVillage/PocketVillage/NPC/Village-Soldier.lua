Soldier = {}

function Soldier:new(game)	
	local object = { 
		game = game,
	}
	setmetatable(object, { __index = Soldier })
    
    if object.game:getMetaValueForKey("access_granted") == "true" then
        object.game:npc_moveToX_y("Soldier",5,11)
    end
    
	print("Soldier initialized ")

	return object
end 

function Soldier:interact()
    if self.game:getMetaValueForKey("has_cookies") == "true" or self.game:getMetaValueForKey("access_granted") == "true" then
        self.game:npc_say("Soldier","Hrmph...")
        self.game:npc_moveToX_y("Soldier",5,11)
        self.game:setMeta_forKey("true","access_granted")
    else
        self.game:npc_say("Soldier","No one sees the Wizard! Not without a gift!")
    end
end

Soldier = Soldier:new(game)
npcs["Soldier"] = Soldier