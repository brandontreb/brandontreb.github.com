Boy = {}

function Boy:new(game)	
	local object = { 
		game = game,
	}
	setmetatable(object, { __index = Boy })
    
	print("Boy initialized ")

	return object
end 

function Boy:interact()
	
	if self.game:getMetaValueForKey("quest_fish") == "true" then
		if self.game:getMetaValueForKey("has_bait") == "true" then
			self.game:npc_say("Boy","Did you eat the worm I gave you?")
		else
    		self.game:npc_say("Boy","Here, take one of my worms. It's slimy.")
			self.game:setMeta_forKey("true","has_bait")
		end
	else
		self.game:npc_say("Boy","I like catching worms and eating them.")
	end
end

Boy = Boy:new(game)
npcs["Boy"] = Boy