Priestess = {}

function Priestess:new(game)	
	local object = { 
		game = game,
	}
	setmetatable(object, { __index = Priestess })
    
	print("Priestess initialized ")

	return object
end 

function Priestess:interact()

    if self.game:getMetaValueForKey("quest_see_wendy") == "true" and self.game:getMetaValueForKey("has_cookies") ~= "true" then
        self.game:npc_say("Priestess","Take these cookies to the wizard. They are his favorite!")
        self.game:setMeta_forKey("true","has_cookies")
    else
        self.game:npc_say("Priestess","Is't it magical out today?")
    end
end

Priestess = Priestess:new(game)
npcs["Priestess"] = Priestess