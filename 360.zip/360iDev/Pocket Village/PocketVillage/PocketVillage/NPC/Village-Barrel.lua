Barrel = {}

function Barrel:new(game)	
	local object = { 
		game = game,
	}
	setmetatable(object, { __index = Barrel })
    
	print("Barrel initialized ")

	return object
end 

function Barrel:interact()
    self.game:npc_say("Barrel","Looks to be empty...")
end

Barrel = Barrel:new(game)
npcs["Barrel"] = Barrel