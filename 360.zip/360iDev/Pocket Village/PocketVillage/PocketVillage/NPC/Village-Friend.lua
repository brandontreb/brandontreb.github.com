Friend = {}

function Friend:new(game)	
	local object = { 
		game = game,
	}
	setmetatable(object, { __index = Friend })
    
	print("Friend initialized ")

	return object
end 

function Friend:interact()
    -- Calls: 
    -- - (void) npc: (NSString *)npc say:(NSString *) text 
    -- inside of game layer
    
	self.game:npc_say("Friend","You want to go on an adventure? Perhaps The Wizard can help?")
end

friend = Friend:new(game)
npcs["Friend"] = friend