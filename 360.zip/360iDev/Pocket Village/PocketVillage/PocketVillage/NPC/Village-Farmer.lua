Farmer = {}

function Farmer:new(game)	
	local object = { 
		game = game,
	}
	setmetatable(object, { __index = Farmer })
    
	print("Farmer initialized ")

	return object
end 

function Farmer:interact()

    local fishCount = tonumber(self.game:getMetaValueForKey("fish_count"))

    if fishCount ~= nil and fishCount > 0 then
        self.game:setMeta_forKey("true","quest_see_wendy")
        self.game:npc_say("Farmer","Thanks!, Wendy in the northeast part of the village has a gift for you.")        
        self.game:setMeta_forKey(tostring(0),"fish_count")
        
    else
    
        if self.game:getMetaValueForKey("quest_fish") == "true" then
            self.game:npc_say("Farmer","Catch me 1 fish and I'll tell ya somethin' amazin...")
        else
            self.game:npc_say("Farmer","Wishin' well? That there is a fishin' well. Ya need a pole and bait though.")
            self.game:setMeta_forKey("true","quest_fish")
        end
    end
end

Farmer = Farmer:new(game)
npcs["Farmer"] = Farmer