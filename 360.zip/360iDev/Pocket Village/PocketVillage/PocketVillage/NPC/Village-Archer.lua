Archer = {}

function Archer:new(game)	
	local object = { 
		game = game,
	}
	setmetatable(object, { __index = Archer })
    
	print("Archer initialized ")
	
	return object
end 

function Archer:interact()

    if self.game:getMetaValueForKey("quest_fish") == "true" then

		if self.game:getMetaValueForKey("has_pole") == "true" then
			self.game:npc_say("Archer","Any luck with that pole I gave you?")
		else		
    		self.game:npc_say("Archer","Here's a fishing pole. She'll catch you a fish \"This Big\".")
			self.game:setMeta_forKey("true","has_pole")			
		end
	else
		self.game:npc_say("Archer","If you ever need a fishing pole, stop by and see me.")
	end
end

Archer = Archer:new(game)
npcs["Archer"] = Archer