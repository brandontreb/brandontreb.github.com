Wizard = {}

function Wizard:new(game)	
	local object = { 
		game = game,
	}
	setmetatable(object, { __index = Wizard })
    
	print("Wizard initialized ")

	return object
end 

function Wizard:interact()

    if self.game:getMetaValueForKey("has_cookies") == "true" then
        self.game:npc_say("Wizard","Thanks for the cookies. Now... what do you want?")
        self.game:setMeta_forKey("false","has_cookies")
    else
        self.game:npc_say("Wizard","You have passed the test. Now prepare to embark on your adventure...")
        self.game:theEnd()
    end
end

Wizard = Wizard:new(game)
npcs["Wizard"] = Wizard