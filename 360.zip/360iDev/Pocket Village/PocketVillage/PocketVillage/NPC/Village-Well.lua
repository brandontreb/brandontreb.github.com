Well = {}

function Well:new(game)	
	local object = { 
		game = game,
	}
	setmetatable(object, { __index = Well })
    
	print("Well initialized ")
	math.randomseed( os.time() )
	
	return object
end 

function Well:interact()
    if self.game:getMetaValueForKey("has_pole") == "true" and self.game:getMetaValueForKey("has_bait") == "true" then
        local status = math.random(5)

		if status == 1 or status == 2 then
			local fishCount = tonumber(self.game:getMetaValueForKey("fish_count"))
			
			if fishCount == nil then
				fishCount = 0
			end
			
			fishCount = fishCount + 1
			
			self.game:setMeta_forKey(tostring(fishCount),"fish_count")
			
			self.game:npc_say("Well", "You caught a fish! You now have " .. tostring(fishCount))
			
		elseif status == 3 then
			
			--self.game:setMeta_forKey("false","has_bait")
			self.game:npc_say("Well", "This fish took your bait!")
		else
			self.game:npc_say("Well", "Almost had him...")
		end

    else
        self.game:npc_say("Well","Look at all of those fish. If only I had a pole and some bait")
    end
end

Well = Well:new(game)
npcs["Well"] = Well