//
//  NPCManager.h
//  PocketVillage
//
//  Created by Brandon Trebitowski on 8/27/12.
//
//

@class GameLayer;

@interface NPCManager : NSObject
@property(nonatomic, strong) NSMutableDictionary *npcs;

- (void) interactWithNPCNamed:(NSString *) npcName;
- (id) initWithGameLayer:(GameLayer *)layer;
- (void)loadNPCsForTileMap:(CCTMXTiledMap *) map named:(NSString *) name;
@end
