//
//  IntroLayer.m
//  PocketVillage
//
//  Created by Brandon Trebitowski on 8/22/12.
//  Copyright brandontreb.com 2012. All rights reserved.
//


// Import the interfaces
#import "GameOverLayer.h"

#pragma mark - IntroLayer

// HelloWorldLayer implementation
@implementation GameOverLayer

// Helper class method that creates a Scene with the HelloWorldLayer as the only child.
+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	GameOverLayer *layer = [GameOverLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// 
-(void) onEnter
{
	[super onEnter];

	// ask director for the window size
	CGSize size = [[CCDirector sharedDirector] winSize];

    CCLabelTTF *label = [CCLabelTTF labelWithString:@"Fin" fontName:@"Marker Felt" fontSize:45];
	label.position = ccp(size.width/2, size.height/2);

	// add the label as a child to this Layer
	[self addChild: label];
	
    // Clear the data store
    NSString *appDomain = [[NSBundle mainBundle] bundleIdentifier];
    [[NSUserDefaults standardUserDefaults] removePersistentDomainForName:appDomain];
    
}

@end
