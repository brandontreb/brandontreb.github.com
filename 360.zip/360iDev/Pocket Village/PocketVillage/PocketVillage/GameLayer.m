//
//  HelloWorldLayer.m
//  PocketVillage
//
//  Created by Brandon Trebitowski on 8/22/12.
//  Copyright brandontreb.com 2012. All rights reserved.
//


// Import the interfaces
#import "GameLayer.h"
#import "GameOverLayer.h"

// Needed to obtain the Navigation Controller
#import "AppDelegate.h"
#import "NPCManager.h"

#define kGameScale 5
#define kMapName @"Village"

@interface GameLayer()
@property(nonatomic, strong) CCTMXTiledMap *tileMap;
@property (nonatomic, strong) CCTMXLayer *metaLayer;
@property (nonatomic, strong) CCTMXLayer *npcLayer;
@property (nonatomic, strong) CCTMXLayer *itemLayer;
@property(nonatomic, strong) CCSpriteBatchNode *batchNode;
@property(nonatomic, strong) CCSprite *hero;
@property(nonatomic, strong) NSString *mapName;
@property(nonatomic, strong) CCLayer *chatbox;
@property(nonatomic) BOOL moved;
@property(nonatomic) CGPoint startingTouchLocation;
@end

// HelloWorldLayer implementation
@implementation GameLayer

// Helper class method that creates a Scene with the HelloWorldLayer as the only child.
+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	GameLayer *layer = [GameLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

-(id) init
{
	if( (self=[super init]) ) {
        self.mapName = kMapName;
        NSString *filename = [NSString stringWithFormat:@"%@.tmx",self.mapName];
        
        // Init the npc manager
        self.npcManager = [[NPCManager alloc] initWithGameLayer:self];
        [self loadMapNamed:filename];
        
        // Init our hero and add to the scene
        self.hero = [CCSprite spriteWithFile:@"characters.png" rect:CGRectMake(0,0,8,9)];
        [self.hero.texture setAliasTexParameters];
        self.hero.position = CGPointMake(100, 68);
        self.hero.scale = kGameScale;
        [self addChild:self.hero z:1];
        
        // Enable touches
        CCDirector *director = [CCDirector sharedDirector];
        [[director touchDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
        
	}
	return self;
}

/**
 * Loads a tilemap from the bundle path with a given name. The map is
 * assumed to have at least 4 layers.
 * - Main Layer: Displays the core tiles
 * - NPC Layer: Contains NPCs. All must have a property "Name", which corresponds
 *              to their related Lua file.
 * - Meta Layer: Used for collision detection
 * - Items Layer: Similar to NPC layer
 *
 * All NPCs and items are automatically loaded using the NPCManager.
 */
- (void) loadMapNamed:(NSString *) name
{
    self.tileMap = [CCTMXTiledMap tiledMapWithTMXFile:name];
    [self.tileMap setScale:kGameScale];
    [self addChild:self.tileMap z:-1];
    self.metaLayer = [self.tileMap layerNamed:@"Meta"];
    self.metaLayer.visible = NO;
    self.npcLayer = [self.tileMap layerNamed:@"NPC"];
    self.itemLayer = [self.tileMap layerNamed:@"Items"];
    
    [self.npcManager loadNPCsForTileMap:self.tileMap named:self.mapName];
}

/**
 * Centers the view on our character.  If the character is near the edge
 * of the map, the view won't change.  Only the character will move.
 *
 */
-(void)setViewpointCenter:(CGPoint) position {
    
    CGSize winSize = [[CCDirector sharedDirector] winSize];
    
    int x = MAX(position.x, winSize.width / 2);
    int y = MAX(position.y, winSize.height / 2);
    x = MIN(x, (_tileMap.mapSize.width * 8)*kGameScale
            - winSize.width / 2);
    y = MIN(y, (_tileMap.mapSize.height * 8)*kGameScale
            - winSize.height/2);
    CGPoint actualPosition = ccp(x, y);
    
    CGPoint centerOfView = ccp(winSize.width/2, winSize.height/2);
    CGPoint viewPoint = ccpSub(centerOfView, actualPosition);
    self.position = viewPoint;    
}

-(BOOL) ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	return YES;
}

/**
 * Moves the player to a given position. Also performs collision detection
 * against the meta layer for tiles with the property "Collidable" set
 * to true.
 *
 * If the player encounters an NPC or an item, they are no permitted to move
 * and the logic is handed off to the NPCManager to execut the related lua
 * script.
 */
-(void)setPlayerPosition:(CGPoint)position {
	CGPoint tileCoord = [self tileCoordForPosition:position];
    
    // Check walls
    int tileGid = [self.metaLayer tileGIDAt:tileCoord];
    if (tileGid) {
        NSDictionary *properties = [self.tileMap propertiesForGID:tileGid];
        if (properties) {
            NSString *collision = [properties valueForKey:@"Collidable"];
            if (collision && [collision compare:@"True"] == NSOrderedSame) {
                return;
            }
        }
    }
    
    // Check npc
    tileGid = [self.npcLayer tileGIDAt:tileCoord];
    if(tileGid)
    {
        NSDictionary *properties = [self.tileMap propertiesForGID:tileGid];
        NSString *name = [properties objectForKey:@"Name"];
        [self.npcManager interactWithNPCNamed:name];
        return;
    }
    
    // Check item
    tileGid = [self.itemLayer tileGIDAt:tileCoord];
    if(tileGid)
    {
        NSDictionary *properties = [self.tileMap propertiesForGID:tileGid];
        NSString *name = [properties objectForKey:@"Name"];
        [self.npcManager interactWithNPCNamed:name];
        return;
    }
    
    self.hero.position = position;
}

/**
 * Invokes player movement or dissmisal of the chat window.
 */
-(void) ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
    // Dismiss the chatbox if it's visible
    if(self.chatbox && self.chatbox.visible)
    {
        [self.chatbox setVisible:NO];
        [self removeChild:self.chatbox cleanup:YES];
        return;
    }
    
    CGPoint touchLocation = [touch locationInView: [touch view]];
    touchLocation = [[CCDirector sharedDirector] convertToGL: touchLocation];
    touchLocation = [self convertToNodeSpace:touchLocation];
    
    CGPoint playerPos = self.hero.position;
    CGPoint diff = ccpSub(touchLocation, playerPos);
    if (abs(diff.x) > abs(diff.y)) {
        if (diff.x > 0) {
            playerPos.x += 8 * kGameScale;//8;
        } else {
            playerPos.x -= 8 * kGameScale;
        }
    } else {
        if (diff.y > 0) {
            playerPos.y += 8 * kGameScale;
        } else {
            playerPos.y -= 8 * kGameScale;
        }
    }
        
    if (playerPos.x <= (_tileMap.mapSize.width * 8 * kGameScale)  &&
        playerPos.y <= (_tileMap.mapSize.height * 8 * kGameScale)  &&
        playerPos.y >= 0 &&
        playerPos.x >= 0 )
    {
        [self setPlayerPosition:playerPos];
    }
    
    [self setViewpointCenter:self.hero.position];
    
}

/**
 * Given a point on the map, returns the tile coordinate for that point.
 */
- (CGPoint)tileCoordForPosition:(CGPoint)position {
    int x = position.x / (8 * kGameScale);
    int y = ((_tileMap.mapSize.height * 8 * kGameScale) - position.y) / (8 * kGameScale);
    return ccp(x, y);
}

- (void) dealloc
{
    [_tileMap release];
    [_metaLayer release];
    [_npcLayer release];
    [_itemLayer release];
    [_batchNode release];
    [_hero release];
    [_mapName release];
    [_chatbox release];
    [_npcManager release];
	[super dealloc];
}

#pragma mark - API

/**
 * Displays a chat window for a given NPC.
 */
- (void) npc: (NSString *)npc say:(NSString *) text
{
    self.chatbox = [[CCLayer alloc] init];
    CCSprite *backroundSprite = [CCSprite spriteWithFile:@"chat-box.png"];
    [backroundSprite.texture setAliasTexParameters];
    backroundSprite.scale = 8;
    backroundSprite.position = ccp(0,240);
    backroundSprite.anchorPoint = ccp(0,0);
    [self.chatbox addChild:backroundSprite z:0];
    
    NSString *message = [NSString stringWithFormat:@"%@: %@",npc, text];
    
    CCLabelTTF *label = [CCLabelTTF labelWithString:message dimensions:CGSizeMake(460, 60) hAlignment:UITextAlignmentLeft lineBreakMode:UILineBreakModeWordWrap fontName:@"Helvetica" fontSize:24];
    label.color = ccWHITE;
    label.anchorPoint = ccp(0, 0);
    label.position = ccp(10,250);
    [self.chatbox addChild:label z:1];
    [self.parent addChild:self.chatbox];
}

/**
 * Allows an NPC to move from one tile to another.
 */
- (void) npc: (NSString *)npc moveToX:(NSInteger) x y:(NSInteger) y
{
    CGPoint tilePoint = CGPointMake(x, y);
    int npcGid = 0;
    
    for(int i = 0; i < self.npcLayer.layerSize.width; i++)
    {
        for(int j = 0; j < self.npcLayer.layerSize.height; j++)
        {
            CGPoint tileCoord = CGPointMake(j,i);
            int tileGid = [self.npcLayer tileGIDAt:tileCoord];
            if(tileGid)
            {
                NSDictionary *properties = [self.tileMap propertiesForGID:tileGid];
                NSString *npcName = [properties objectForKey:@"Name"];
                
                if ([npcName isEqualToString:npc]) {
                    npcGid = tileGid;
                    [self.npcLayer setTileGID:0 at:tileCoord];
                }
            }
        }
    }
    
    if(npcGid)
    {
        [self.npcLayer setTileGID:npcGid at:tilePoint];
    }
    
}

/**
 * Updates a meta value in the NSUserDefaults
 */
- (void) setMeta:(NSString *)value forKey:(NSString *)key
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:value forKey:key];
    [defaults synchronize];
}

/**
 * Retrieves a meta value from the NSUserDefaults
 */
- (NSString *) getMetaValueForKey:(NSString *)key
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    return [defaults objectForKey:key];
}

/**
 * Transitions to the game over screen
 */
- (void) theEnd
{
    // In one second transition to the new scene
	[self scheduleOnce:@selector(makeTransition:) delay:1.5];
}

-(void) makeTransition:(ccTime)dt
{
	[[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[GameOverLayer scene] withColor:ccWHITE]];
}

@end
