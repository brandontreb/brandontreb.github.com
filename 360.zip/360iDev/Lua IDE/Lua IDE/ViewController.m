//
//  ViewController.m
//  Lua IDE
//
//  Created by Brandon Trebitowski on 9/5/12.
//  Copyright (c) 2012 Brandon Trebitowski. All rights reserved.
//

#import "ViewController.h"
#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"
#include <stdlib.h>
#include <fcntl.h>

@interface ViewController ()
@property(weak) IBOutlet UITextView *luaTextView;
@property(weak) IBOutlet UITextView *resultTextView;
@property(nonatomic) lua_State *luaState;
- (IBAction)run:(id)sender;
@end

id myClass;

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Initialize lua
    self.luaState = lua_open();
    luaopen_base(self.luaState);
    
    // Give C error function class access
    myClass = self;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (void) viewWillAppear:(BOOL)animated
{
    [self.luaTextView becomeFirstResponder];
}

- (IBAction)run:(id)sender
{
    NSString *luaCode = self.luaTextView.text;
    
    // Set up buffers
    char buffer[256] = {0};
    int out_pipe[2];
    int saved_stdout;
    
    // Set up pipes for stdout
    saved_stdout = dup(STDOUT_FILENO);
    pipe(out_pipe);
    fcntl(out_pipe[0], F_SETFL, O_NONBLOCK);
    dup2(out_pipe[1], STDOUT_FILENO);
    close(out_pipe[1]);
    
    // Run Lua
    luaL_loadstring(self.luaState, [luaCode UTF8String]);
    int status = lua_pcall(self.luaState, 0, LUA_MULTRET, 0);
    
    // Report errors if there are any
    report_errors(self.luaState, status);
    
    // If status returns 0 (success) pipe the output to our buffer
    // and display the result in the text view
    if(!status)
    {
        // Grab the output
        read(out_pipe[0], buffer, 255);
        dup2(saved_stdout, STDOUT_FILENO);
        
        // Format the output
        NSString *output = [NSString stringWithCString:buffer encoding:NSUTF8StringEncoding];
            
        self.resultTextView.text = output;
    }

}

void report_errors(lua_State *L, int status)
{
    if ( status != 0 ) {
        // Grab the error at the top of the lua stack
        const char *error = lua_tostring(L, -1);
        // Gain access to our class
        ViewController *viewController = (ViewController *) myClass;
        viewController.resultTextView.text = [NSString stringWithFormat:@"**Error** %s",error];
        // remove error message from the lua stack
        lua_pop(L, 1);
    }
}

@end
